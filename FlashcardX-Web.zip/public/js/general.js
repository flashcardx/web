
function checkUndefined(value){
    if(value === undefined)
        return ""
    else
        return value;
}